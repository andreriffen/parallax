# Parallax

## Efeito visual 🖱️ Experimento rápido de Javascript

Demonstra o uso de '*escutador de eventos*' (*Event Listener*) no movimento do mouse. Move 3 imagens simultaneamente em velocidades diferentes.

## 🕹️ [Demonstração (GitHub) »](https://github.com/your-username/parallax-experiment)

Você pode ver o efeito de parallax em ação [**clicando aqui »»**](https://github.com/your-username/parallax-experiment)

### ☕ Autor

- 2023 ©️ **Andre Riffen** - [Perfil GitHub](https://github.com/your-username)
